# Python Flask Application — Jenkins Webhook Deployment

A small Python web application built with Flask and deployed on an AWS EC2 instance. The browser screenshot shows the application responding on port `5000` with the message:

> successfully deployed python application through jenkins!!!!!!!!, added webhook

## Project overview

- **Project folder:** `Python-project-deploy`
- **Application file:** `app.py`
- **Dependencies file:** `requirements.txt`
- **Python environment:** `shivamenv` (virtual environment)
- **Framework:** Flask
- **Port:** `5000`
- **Deployment platform:** AWS EC2

## Project files

- `app.py` — Python application entry point.
- `requirements.txt` — required Python packages, including Flask and Gunicorn.
- `shivamenv/` — virtual environment created on EC2. Recreate it on the server instead of committing it to Git.
- `README.md` — project documentation.
- `Screenshot 2026-10-14 125212.png` — screenshot of the running application.

## Application output

The deployed page displays:

> successfully deployed python application through jenkins!!!!!!!!, added webhook

The screenshot shows the application at `98.89.39.32:5000`.

## Run the application on EC2

### 1. Clone the repository

Replace the placeholder with your repository URL:

```bash
git clone YOUR_REPOSITORY_URL
cd Python-project-deploy
```

### 2. Create and activate a virtual environment

```bash
python3 -m venv shivamenv
source shivamenv/bin/activate
```

Run `source` in your current Bash terminal without `sudo`. `sudo bash shivamenv/bin/activate` does not activate the environment in your current shell.

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Your terminal history mentions changing Click from `8.4.1` to `8.1.8`; check `requirements.txt` to confirm the version currently specified.

### 4. Start the application

```bash
python app.py
```

Alternatively, if `app.py` defines a Flask application object named `app`, run it with Gunicorn:

```bash
gunicorn --bind 0.0.0.0:5000 app:app
```

For a temporary background run:

```bash
gunicorn --bind 0.0.0.0:5000 app:app --daemon
```

`app:app` assumes the filename is `app.py` and the Flask variable inside it is named `app`.

### 5. Open it in a browser

```text
http://YOUR-EC2-PUBLIC-IP:5000
```

The screenshot used `98.89.39.32:5000`. Use the current public IPv4 address from the EC2 console, since public IPs can change.

The EC2 security group must allow inbound TCP port `5000` from your IP for testing. Avoid exposing the port publicly unless required.

## Useful commands

```bash
ls -la
source shivamenv/bin/activate
pip install -r requirements.txt
python app.py
gunicorn --bind 0.0.0.0:5000 app:app
ps aux | grep '[g]unicorn'
```

Press `Ctrl+C` to stop an application running in the foreground. For a daemonized process, identify the correct process before stopping it.

## Troubleshooting

### Missing Flask or another package

Activate the virtual environment and run:

```bash
python -m pip install -r requirements.txt
```

### Browser cannot reach port 5000

- Confirm the app is still running.
- Confirm Gunicorn binds to `0.0.0.0:5000` for external access.
- Confirm the EC2 security group permits TCP port `5000`.
- Check the instance's current public IP.
- If needed, check the subnet route table and network ACL.

## Jenkins and webhook note

The page's message mentions Jenkins and a webhook. The screenshot confirms the app was reachable in a browser, but the supplied details do not independently document the Jenkins pipeline or webhook configuration.

## Screenshot: successful deployment

Keep the screenshot in the same folder as this README with the exact filename:

`Screenshot 2026-10-14 125212.png`

![Python Flask application deployed on EC2](Screenshot%202026-10-14%20125212.png)

## Learning outcomes

This project practises cloning a Git repository, creating a Python virtual environment, installing dependencies, running Flask with Gunicorn, deploying on EC2, and configuring security-group access.
